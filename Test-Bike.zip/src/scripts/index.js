import "./autoload/_bootstrap"
import "./autoload/_slick"
import "./main"